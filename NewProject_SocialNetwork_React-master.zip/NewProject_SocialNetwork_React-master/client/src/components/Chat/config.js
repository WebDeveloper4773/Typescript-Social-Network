const tokenUrl = "https://us1.pusherplatform.io/services/chatkit_token_provider/v1/a3c3748d-40c9-4409-ad19-7b6f72511fb3/token";
const instanceLocator = "v1:us1:a3c3748d-40c9-4409-ad19-7b6f72511fb3";

export { tokenUrl, instanceLocator }