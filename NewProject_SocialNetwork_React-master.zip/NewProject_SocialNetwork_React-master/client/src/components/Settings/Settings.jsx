import React from 'react';
import c from './Settings.module.css';

const Settings = () => {
  return (
    <div>
      Settings
    </div>  
  );
}

export default Settings;