import React from 'react';
import c from './Music.module.css';

const Music = () => {
  return (
    <div>
      Music
    </div>
    
  );
}

export default Music;